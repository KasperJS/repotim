import re
import sqlite3
import json
from contextlib import closing
from typing import List
from typing import Set
from typing import Tuple
from urllib.parse import urljoin
from urllib.parse import urlparse
from requests import session as RequestsSession
from bs4 import BeautifulSoup
from dateutil import parser
from fake_useragent import UserAgent
from requests import ConnectionError as RequestsConnectionError
from requests import session as Session

from config import logger
from config import settings
from db.queries import add_phones
from db.queries import create_ad
from db.queries import create_author
from db.queries import get_author_id
from db.queries import get_exists_ads
from db.utils import check_db
from olx.utils import _get_landlord_created_at
from olx.utils import _get_landlord_id
from olx.utils import _get_landlord_name
from olx.utils import _get_landlord_other_ads_count
from olx.utils import _get_landlord_url
from utils import RussianParserInfo
from utils import build_url
from utils.models import AdModel
from utils.models import LandLordModel
from utils.models import NewAdModel
from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import InlineKeyboardButton,InlineKeyboardMarkup
from telegram import Bot

import time
from typing import List

Bearer = "Bearer abb12790abda389d9375f5d6463170730f0e3ada"
#Bearer = "Bearer ea80aa4c2397db17f4f5412f649e2a57f51945f9"

def fetch_ads( pages) -> Set[AdModel]:
    
    ads = []
    bot = Bot(token=settings.TELEGRAM_BOT_KEY)
    
    F_UserReg = "2020"
    F_ColllOferr = 3
    i = 1
    logger.info('=== Starting fetch ads ===')
    
    while i < pages:   
      with RequestsSession() as session:
        try:
            url = "https://www.olx.pl/d/muzyka-edukacja/?search%5Bprivate_business%5D=private&page="
            #url = "https://www.olx.pl/d/moda/akcesoria/?search%5Bprivate_business%5D=private&page="
            print(f'{i}')
            url = url+str(i)
            print("URLLL: "+url)
            
            response = session.get(f'{url}{i}')    
            rozdel = 0
            i = i + 1 
            if response.status_code != 200:
                print("EGGORR URL 1: "+str(url))
                continue

            soup = BeautifulSoup(response.content.decode('utf-8'), 'lxml')
            ads_items = soup.find_all(attrs={"data-cy": "l-card"})
            #ads_items = soup.find_all(class_="offer-wrapper")
            print('++++ Start processing %s', len(ads_items))        
            
            for item in ads_items:
                
                user_date = ""
                user_name = ""
                item_url  = ""
                olx_price = ""
                olx_title = ""
                
          
                
                #item_url1 = item.find(attrs={"data-cy": "listing-ad-title"}).attrs.get('href').split('#')
                item_url1 = item.find('a', class_="css-1bbgabe").attrs.get('href').split('#')
                item_url = "https://www.olx.pl"+item_url1[0]  
                print('++++ item_url %s', item_url)
                
                responseDetail = session.get(item_url)
                if responseDetail.status_code != 200:
                    print("EGGORR URL 1: "+str(item_url))
                    continue
                    
                soup_ads = BeautifulSoup(responseDetail.content.decode('utf-8'), 'lxml')   
                           
                try: 
                    ads_user_url = soup_ads.find(attrs={"name": "user_ads"}).attrs.get('href') 
                    adPhotos = soup_ads.find(attrs={"data-testid": "swiper-image"}).attrs.get('src')
                    #adPhotos = adPhotos.attrs.get('src')
                    ads_user_url = 'https://www.olx.pl'+ads_user_url
                    user_date = soup_ads.find('div', class_='css-1bafgv4-Text eu5v0x0').text
                    user_name = soup_ads.find('h2', class_='css-u8mbra-Text eu5v0x0').text
                    user_name = soup_ads.find('h2', class_='css-u8mbra-Text eu5v0x0').text
                    #ads_view = soup_ads.find_all(text="window.__PRERENDERED_STATE__=")
                    ads_view = soup_ads.find(id="olx-init-config")
                    ads_view = str(ads_view).split('window.__PRERENDERED_STATE__= "')
                    ads_view = str(ads_view[1]).split('window.')
                    ads_view = str(ads_view[0]).split('";')
                    s1 = ads_view[0].replace("\\", "")
                    ads_view_obj = json.loads(json.loads(json.dumps(s1)))
                    
                    ads_id = ads_view_obj["ad"]["ad"]["id"] # id ADS
                    ads_title = ads_view_obj["ad"]["ad"]["title"] # id title
                    ads_createdTime = ads_view_obj["ad"]["ad"]["createdTime"] # id title
                    ads_price = ads_view_obj["ad"]["ad"]["price"]["regularPrice"]["value"] # id price
                    ads_description = ads_view_obj["ad"]["ad"]["description"] # id description
                    ads_photos = ads_view_obj["ad"]["ad"]["photos"][0] # id ads_photos
                    ads_user_name = ads_view_obj["ad"]["ad"]["user"]["name"] # имя пользователя
                    ads_user_id = ads_view_obj["ad"]["ad"]["user"]["id"] # id пользователя
                    ads_user_created = ads_view_obj["ad"]["ad"]["user"]["created"] # ата регистрации пользователя
                except: 
                    continue                
                
                userregdatya = str(user_date.split(' ')[4])
                if F_UserReg <= userregdatya:
                     
                     response_user = session.get(ads_user_url)
                     if response_user.status_code != 200:
                         print("EGGORR URL 2: "+str(response_user))
                         continue
                     
                     soup_response_user = BeautifulSoup(response_user.content.decode('utf-8'), 'lxml')
                     response_user_itm = soup_response_user.find_all('div', class_='offer-wrapper')
                     user_offer = len(response_user_itm)
                     
                    
                     
                     if user_offer < F_ColllOferr:
                        with open('ads_log.txt', 'r', encoding='utf-8') as values_to_compare:
                             values = values_to_compare.readlines()
                             its_new = 0
                             for v in values:
                                 olx_id_n = f'id:{ads_id}'
                                 if v.split(' url')[0] == olx_id_n:
                                     its_new = 1
                                     print('++++ ЕСТЬ ОБЯВЫ %s', olx_id_n)
                                     continue
                             if its_new == 0:        
                                 text = f'''
                                         `️⚡{ads_title}⚡`                         
                                        \n Ссылка: [перейти]({item_url}) \n Получить номер: `/GetNumber {ads_id}`  \n Цена: {ads_price} zł\n Имя: {user_name}\n Количество объявлений: {user_offer} \n Дата создание аккаунта: {ads_user_created}\n Дата создание обявления: {ads_createdTime} 
                                         
                                        '''
                                 bot.send_message(chat_id=-1001785616022, text=text, parse_mode='Markdown')
                                 time.sleep(0.250)
                                 linfile = f'id:{ads_id} url:{item_url}'
                                 printToFile(linfile)
                                         
        except:
             i = i + 1
             time.sleep(1)
             continue
                    
    text = f'''🟢 Работу закончил 🟢'''
    bot.send_message(chat_id=-1001785616022, text=text, parse_mode='HTML')          
    return
    
def printToFile(str):
    file_name = 'ads_log.txt'
    with open(file_name,'a') as f:
        print(str)
        f.write(str + '\n')

def GetNumb_new_ads(session: Session, olx_id):
    with open('ads_log.txt', 'r', encoding='utf-8') as values_to_compare:
        values = values_to_compare.readlines()
    
    url = ""    
    for v in values:
        olx_id_n = f'id:{olx_id}'        
        if v.split(' url')[0] == olx_id_n:
          url = v.split('url:')[1] 
          print("url "+ url )
          
            
        headers = {
            'authorization': Bearer,
        }
        #phoneurl = "https://www.olx.pl/api/v1/offers/"+olx_id+"/limited-phones/"
        phoneurl = f'https://www.olx.pl/api/v1/offers/{olx_id}/limited-phones/'
        responsePhone = session.get(phoneurl, headers=headers)                
        if responsePhone.status_code == 200:                    
            userphone = json.loads(responsePhone.content.decode('utf-8'))
            tel = userphone["data"]["phones"][0].replace("-", "")
            tel = f'`https://api.whatsapp.com/send?phone=48{tel}&text=%20Dzień%20dobry.%20Czy%20ogłoszenie%20jest%20dalej%20aktualne?%27`'
            #tels = tel
            
        else:
            tel="Не найден"
    print("responsePhone "+ responsePhone.content.decode('utf-8'))   
    return tel

def GetShablon(num):
    phone = num.replace(" ", "")
    shablon = f'https://api.whatsapp.com/send?phone=48{phone}&text=Dzień%20dobry.%20Czy%20ogłoszenie%20jest%20dalej%20aktualne?%27'
    
    return shablon

def fetch_ads_detail(session: Session, ad: AdModel) -> Tuple[AdModel, LandLordModel, List[str]] or None:

    logger.debug('=== Starting to fetch landlord telephone number and name ===')
    
    logger.debug('-+-+-+-+-+-+-+--+-+-+-+-+-+-+-+-+ad.url === '+ad.url)
    

    # fetch landlord info
    
    return 
