from datetime import datetime
from typing import List
from typing import NamedTuple


class AdModel(NamedTuple):
    user_date:str
    user_name:str
    olx_price:str
    olx_title:str
    url:str


class NewAdModel(NamedTuple):
    user_date:str
    user_name:str
    olx_price:str
    olx_title:str
    url:str


class LandLordModel(NamedTuple):
    external_id: str
    url: str
    name: str
    platform_created_at: datetime.date
    other_ads: int
