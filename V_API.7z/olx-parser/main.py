import time

from requests import session as RequestsSession
from telegram import Bot

from config import logger
from config import settings
from olx import fetch_ads
from olx import GetNumb_new_ads
from olx import GetShablon
from tg import send_message_into_telegram
from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import InlineKeyboardButton,InlineKeyboardMarkup
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.contrib.fsm_storage.memory import MemoryStorage


bot = Bot(token=settings.TELEGRAM_BOT_KEY)
dp = Dispatcher(bot, storage=MemoryStorage())

def main():    
    pages = 2
    new_ads = []
    #with RequestsSession() as session:
    #    fetch_ads(session, 20)
         
    @dp.message_handler(commands="start")
    async def cmd_start(message: types.Message):
        keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
        buttons = ["📄 2", "📄 5","📄 10","📄 20","📄 30","📄 40","📄 50"]
        keyboard.add(*buttons)
        await message.answer("Сколько страниц просканировать?", reply_markup=keyboard)
    
    @dp.message_handler(lambda message: message.text.split(' ')[0] == "📄")
    async def without_puree(message: types.Message):
        returnnumb = message.text.split(' ')[1]        
        await message.reply(returnnumb)
        with RequestsSession() as session:
            fetch_ads(int(returnnumb))
    
    @dp.message_handler(commands="GetNumber")
    async def GetNumber(message: types.Message):
        num = message.text.split("GetNumber ")
        with RequestsSession() as session:
             phone = GetNumb_new_ads(session, str(num[1]))        
        await message.reply(str(phone))     
        
        
    @dp.message_handler(commands="s")
    async def GetNumber(message: types.Message):
        num = message.text.split("s ")
        phone = GetShablon(str(num[1]))        
        await message.reply(str(phone))   
        #await message.answer("Нажмите на кнопку, чтобы бот отправил число от 1 до 10", reply_markup=keyboard)
            
   # with RequestsSession() as session:
    #    ads = fetch_ads(session, pages)
   
           # send_message_into_telegram(bot, new_ads)
#            new_ads = filter_new_ads(session, ads)
#    if new_ads:
#        send_message_into_telegram(bot, new_ads)


if __name__ == '__main__':
    main()
    executor.start_polling(dp,skip_updates=True)
    #start_time = time.time()
    #logger.info('=== Script has been started ===')
    #try:
    #    main()
    #except KeyboardInterrupt:
    #    logger.info('=== Script has been stopped manually! ===')
    #except Exception as e:  # pylint: disable=broad-except
    #    logger.exception(e)
    #else:
    #    logger.info('=== Script has been finished successfully ===')
    #finally:
    #    logger.info('=== Operating time is %s seconds ===', (time.time() - start_time))
